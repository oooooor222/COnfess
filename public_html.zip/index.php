<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONFESS</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #29E7FA;
        }
        .header {
            background-color: #69FF2D;
            color: white;
            position: relative;
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
        }
        h1 {
            font-family:cursive;
            margin: 0;
            font-size: 36px;
            float: left;
            color: #04126C;
        }
        .button {
            background-color: #f39c12;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            float: right;
        }
        .button:hover {
            background-color: #e67e22;
        }
    </style>
</head>
<body>

    <div class="header">
        <h1>CONFESS</h1>
        <a href="confess.php" class="button">POST A CONFESS</a>
    </div><br>
    
    <?php
// Database connection parameters
$servername = "localhost"; // Adjust if needed
$username_db = "u261757651_sheema2011";
$password_db = "@Kylie123";
$dbname = "u261757651_sheema";

// Create connection
$conn = new mysqli($servername, $username_db, $password_db, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch submissions
$sql = "SELECT username, text, time FROM confessions ORDER BY time DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confessions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .confession {
            border: 1px solid #000;
            padding: 10px;
            margin: 10px;
            border-radius: 5px;
        }
        .timestamp {
            font-size: 0.8em;
            color: #888;
        }
    </style>
</head>
<body>


<?php
// Displaying the confessions
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='confession'>";
        echo "<strong>CONFESS FROM: " . htmlspecialchars($row['username']) . "</strong><br>";
        echo "<p>" . htmlspecialchars($row['text']) . "</p>";
        echo "<div class='timestamp'>" . htmlspecialchars($row['time']) . "</div>";
        echo "</div>";
    }
} else {
    echo "<p>No confessions yet.</p>";
}

$conn->close();
?>

</body>
</html>
<footer><h2>DEVELOPED BY: Glen Albert Hilario</h2></footer>

</body>
</html>
