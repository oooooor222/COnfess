<?php
// Database connection parameters
$servername = "localhost"; // Adjust if needed
$username_db = "u261757651_sheema2011";
$password_db = "@Kylie123";
$dbname = "u261757651_sheema";

// Create connection
$conn = new mysqli($servername, $username_db, $password_db, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_input = $_POST['username'];
    $text_input = $_POST['text'];
    $time = date("Y-m-d H:i:s"); // Current timestamp

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO confessions (username, text, time) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username_input, $text_input, $time);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect to index.php after successful submission
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confession Box</title>
    <center><h1>CONFESS NOW!</h1></center>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: pink
        }
        .box {
            border: 1px solid #000;
            padding: 20px;
            width: 300px;
            margin: 50px auto;
            background-color: aqua;
        }
    </style>
</head>
<body>
    <div class="box">
        <form action="" method="POST">
            <label for="username">Username:</label><br>
            <input type="text" id="username" name="username" required><br><br>
            <label for="text">Text:</label><br>
            <textarea id="text" name="text" required></textarea><br><br>
            <input type="submit" value="Submit">
        </form>
    </div><br>
    
    <footer><h2>DEVELOPED BY: Glen Albert Hilario</h2></footer>
</body>
</html>